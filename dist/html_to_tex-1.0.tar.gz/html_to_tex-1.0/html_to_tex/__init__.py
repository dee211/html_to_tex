# -*- coding: utf-8 -*-
from html_to_tex.converter import HtmlToTex, html_to_pdf
from html_to_tex.settings import ConverterDefaultConfig

html_tex_converter = HtmlToTex()
